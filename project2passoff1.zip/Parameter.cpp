//
// Created by corbi on 9/28/2021.
//

#include <iostream>
#include "Parameter.h"

std::string Parameter::toString() {
    std::string stringToAdd;
    stringToAdd += parameter;
    return stringToAdd;
}

