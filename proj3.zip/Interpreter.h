//
// Created by corbi on 11/1/2021.
//

#ifndef INC_236PROJECT1_INTERPRETER_H
#define INC_236PROJECT1_INTERPRETER_H

#include "DatalogProgram.h"
#include "Header.h"
#include "Tuple.h"
#include "Database.h"
class Interpreter {
private:
    DatalogProgram datalogtointerpret;
    std::vector<Header> schemeheaders;
    Database database;
    Database databasequery;
    std::vector<Relation> relationvect;
    std::vector<Relation> relationvectquery;
    std::vector<Predicate> schemestoAdd;
    std::vector<Predicate> factstoAdd;
    std::vector<Predicate> queries;
    std::map<std::string, int> seenmap;
    int mapindex = 0;

public:
    Interpreter(DatalogProgram datalog);
    ~Interpreter() = default;

    void CreateRelations();
    void UpdateTuplesOnMap();
    Header getHeader(Predicate &schemetoevaluate);
    Tuple getTuple(Predicate &schemetoevaluate);
    void relationtostring();
    void EvaluateQueries();
    Relation evaluatePredicate(Predicate &p);
};


#endif //INC_236PROJECT1_INTERPRETER_H
