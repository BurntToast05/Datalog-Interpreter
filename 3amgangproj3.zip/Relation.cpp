//
// Created by corbi on 11/1/2021.
//

#include "Relation.h"

std::string Relation::toString() const {
    std::string str;
    for (Tuple t : values)
    {
        str += " ";
        for (size_t i = 0; i < header.getattributessize(); ++i)
        {
            str += " " + header.getAttributes(i) + "=";
            if (i == header.getattributessize() - 1) {
                str += t.getvalueat(i).toString();
            }
            else
            {
                str += t.getvalueat(i).toString() += ",";
            }
        }
        if (header.getattributessize() > 0) {
            str += "\n";
        }
    }
    return str;
}

std::string Relation::toStringRelation() const {

    return std::string();
}

Relation Relation::type1select(Relation currentFacts, size_t columnindex, std::string columntomatch) {
    Relation relationtoreturn(name, header);
    for (Tuple t : values)
    {
        for(Tuple q : currentFacts.getvalues()) {
            for (size_t i = 0; i < header.getattributessize(); ++i) {
                if (i == columnindex) {
                    if (q.getvalueat(i).toString() == columntomatch) {
                        relationtoreturn.addTuple(q);
                    }
                }
            }
        }
    }
    return relationtoreturn;
}

Relation Relation::type2select(Relation currentFacts, size_t columnindex, size_t columntocompare) {
    Relation relationtoreturn(name, header);
    currentFacts.updateheader(header);
    for (Tuple t : values)
    {
        for(Tuple q : currentFacts.getvalues()) {
            for (size_t i = 0; i < header.getattributessize(); ++i) {
                    for (size_t k = 0; k < currentFacts.getheader().getattributessize(); ++k) {
                        if (i == columnindex && k == columntocompare) {
                            if (q.getvalueat(i).toString() == q.getvalueat(k).toString())
                            {
                                relationtoreturn.addTuple(q);
                            }
                        }
                    }
            }
        }
    }
    return relationtoreturn;
}

Relation Relation::project(std::vector<int> columnstokeep) {
    Header newheader;
    Relation relationtoreturn(name, header);
    for (size_t i = 0; i < header.getattributessize(); ++i) {
        if (invect(columnstokeep, i) == true) {
            newheader.addHeader(header.getAttributes(i));
        }
    }
    for (Tuple t : values)
    {
        Tuple tupletoadd;
            for (size_t i = 0; i < header.getattributessize(); ++i) {
                if (invect(columnstokeep, i) == true) {
                    tupletoadd.addValues(t.getvalueat(i).toString());
                }
            }
            relationtoreturn.addTuple(tupletoadd);
    }
    relationtoreturn.updateheader(newheader);
    return relationtoreturn;
}

Relation Relation::rename(std::vector<std::string> eval) {
    Header headertoadd;
    for (size_t i = 0; i < eval.size(); ++i)
    {
        headertoadd.addHeader(eval.at(i));
    }
    Relation relation = Relation(name, headertoadd);
    relation.updateValues(values);
    return relation;
}

