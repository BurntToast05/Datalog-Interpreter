//
// Created by corbi on 11/1/2021.
//

#ifndef INC_236PROJECT1_DATABASE_H
#define INC_236PROJECT1_DATABASE_H
#include "Relation.h"
#include <map>
class Database {
private:
    std::map<std::string, Relation> databasemap;
public:
    Database() = default;
    ~Database() = default;

    void addtomap(std::string toadd, Relation relationtoadd)
    {
        databasemap.insert ( std::pair<std::string,Relation>(toadd, relationtoadd));
    }
    void addfacttomap(std::string ID, Tuple toadd)
    {
        std::map<std::string, Relation>::iterator it = databasemap.find(ID);
        if (it != databasemap.end()) {
            it->second.addTuple(toadd);
        }
    }
    void toString();
    Relation getrelation(std::string ID)
    {
        std::map<std::string, Relation>::iterator it = databasemap.find(ID);
        return it->second;
    }
};
#endif //INC_236PROJECT1_DATABASE_H
